/**
 * 
 */
/**
 * @author Takeogh
 * @version 1.0
 * @created 02-Apr-2020 8:30:00am
 * This package contains all menus and dialogs/interfaces to the user
 */
package operation;