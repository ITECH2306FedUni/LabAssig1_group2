package domain;

/**
 * @author Takeogh
 * @version 1.0
 * @created 02-Apr-2020 8:30:00am
 */
public class Industrial extends Property {

	private String hazardStatus;
	private String heavyVehicleStatus;
	
	public Industrial() {
		System.out.println("Not implemented yet");
	}

	@Override
	public double calculateExtraServices() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setUpExtraServices() {
		// TODO Auto-generated method stub
		
	}

	
}
