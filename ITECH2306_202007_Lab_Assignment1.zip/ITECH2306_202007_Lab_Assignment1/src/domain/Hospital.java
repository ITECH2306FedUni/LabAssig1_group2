package domain;

/**
 * @author Takeogh
 * @version 1.0
 * @created 02-Apr-2020 8:30:00am
 */
public class Hospital{

	public Hospital() {
		System.out.println("Not implemented yet");
	}
}
